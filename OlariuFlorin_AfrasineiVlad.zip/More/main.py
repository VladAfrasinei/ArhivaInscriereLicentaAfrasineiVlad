import requests
import json
import csv

write = csv.writer(open("autovitdata.csv","w"),lineterminator="\n")

def returnOnlyNumber(x):
    y=""
    for carac in x:
        if(carac.isdigit()):
            y=y+carac
    return y

for nr in range(1,3001):
    call='https://www.autovit.ro/i2/ads/?json=1&search[category_id]=29&currency=EUR&page=' + str(nr) + '&fbclid=IwAR05OU0EcEvYsG2U8avnvz33uJBOQxdO7KNXOToYd7ZtHyAuYD5GTKY-WNg'
    response_API = requests.get(call)
    print(nr)
    data = response_API.text
    x=json.loads(data)
    z=x['ads']
    for t in z:
        list1=[]
        p1=list(filter(lambda x:x[0]=='Categorie',t['params']))
        if (p1):
            p1 = p1[0][1]
        p2 = list(filter(lambda x: x[0] == 'Marca', t['params']))
        if (p2):
            p2 = p2[0][1]
        p3 = list(filter(lambda x: x[0] == 'Model', t['params']))
        if (p3):
            p3 = p3[0][1]
        p4 = list(filter(lambda x: x[0] == 'Anul', t['params']))
        if (p4):
            p4 = p4[0][1]
        p5 = list(filter(lambda x: x[0] == 'Km', t['params']))
        if (p5):
            p5 = p5[0][1]
            p5=returnOnlyNumber(p5)
        p6 = list(filter(lambda x: x[0] == 'Combustibil', t['params']))
        if (p6):
            p6 = p6[0][1]
        p7 = list(filter(lambda x: x[0] == 'Putere', t['params']))
        if (p7):
            p7 = p7[0][1]
            p7=returnOnlyNumber(p7)
        p8 = list(filter(lambda x: x[0] == 'Capacitate cilindrica', t['params']))
        if (p8):
            p8 = p8[0][1]
            p8=returnOnlyNumber(p8)
            p8=p8[:-1]
        p9 = list(filter(lambda x: x[0] == 'Transmisie', t['params']))
        if(p9):
            p9=p9[0][1]
        p10 = list(filter(lambda x: x[0] == 'Cutie de viteze', t['params']))
        if (p10):
            p10 = p10[0][1]
        p11 = list(filter(lambda x: x[0] == 'Norma de poluare', t['params']))
        if (p11):
            p11 = p11[0][1]
            p11=returnOnlyNumber(p11)
        p12 = list(filter(lambda x: x[0] == 'Caroserie', t['params']))
        if (p12):
            p12 = p12[0][1]
        ok=0
        if(p1 and p2 and p3 and p4 and p5 and p6 and p7 and p8 and p9 and p10 and p11 and p12):
            list1.append(p1)
            list1.append(p2)
            list1.append(p3)
            list1.append(p4)
            list1.append(p5)
            list1.append(p6)
            list1.append(p7)
            list1.append(p8)
            list1.append(p9)
            list1.append(p10)
            list1.append(p11)
            list1.append(p12)
            ok=1
        if(t['list_label']):
            r=t['list_label']
            q=""
            for carac in r:
                if(carac.isdigit()):
                    q=q+carac
            q1=int(q)
            list1.append(q1)
            if(ok==1):
                write.writerow(list1)
